package io.flutterflow.quizgametemplate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
