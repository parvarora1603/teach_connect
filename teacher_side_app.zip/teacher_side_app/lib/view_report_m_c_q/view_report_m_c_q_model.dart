import '/flutter_flow/flutter_flow_util.dart';
import 'view_report_m_c_q_widget.dart' show ViewReportMCQWidget;
import 'package:flutter/material.dart';

class ViewReportMCQModel extends FlutterFlowModel<ViewReportMCQWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
