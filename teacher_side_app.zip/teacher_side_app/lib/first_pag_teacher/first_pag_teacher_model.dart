import '/flutter_flow/flutter_flow_util.dart';
import 'first_pag_teacher_widget.dart' show FirstPagTeacherWidget;
import 'package:flutter/material.dart';

class FirstPagTeacherModel extends FlutterFlowModel<FirstPagTeacherWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
