import '/flutter_flow/flutter_flow_util.dart';
import 'view_report_written_widget.dart' show ViewReportWrittenWidget;
import 'package:flutter/material.dart';

class ViewReportWrittenModel extends FlutterFlowModel<ViewReportWrittenWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
