// Export pages
export '/first_pag_teacher/first_pag_teacher_widget.dart'
    show FirstPagTeacherWidget;
export '/create_assignment/create_assignment_widget.dart'
    show CreateAssignmentWidget;
export '/view_report/view_report_widget.dart' show ViewReportWidget;
export '/view_report_m_c_q/view_report_m_c_q_widget.dart'
    show ViewReportMCQWidget;
export '/view_report_written/view_report_written_widget.dart'
    show ViewReportWrittenWidget;
