import '/flutter_flow/flutter_flow_util.dart';
import 'view_report_widget.dart' show ViewReportWidget;
import 'package:flutter/material.dart';

class ViewReportModel extends FlutterFlowModel<ViewReportWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
