import { db, Timestamp } from "../../firebase/firebaseConfig"
import { collection, addDoc } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { createdBy, title, type, chapter, topic, difficulty, questions, dueDate, dueTime } = req.body

    // Validate required fields
    if (!createdBy || !title || !type || !chapter || !topic || !difficulty || !questions || !dueDate || !dueTime) {
      return res.status(400).json({ error: "All fields are required" })
    }

    // Validate type
    if (type !== "mcq" && type !== "written") {
      return res.status(400).json({ error: 'Type must be either "mcq" or "written"' })
    }

    // Validate difficulty
    if (!["easy", "medium", "tricky"].includes(difficulty)) {
      return res.status(400).json({ error: 'Difficulty must be "easy", "medium", or "tricky"' })
    }

    // Convert dueDate and dueTime to a single timestamp
    const [year, month, day] = dueDate.split("-").map(Number)
    const [hours, minutes] = dueTime.split(":").map(Number)
    const dueDateTime = new Date(year, month - 1, day, hours, minutes)

    // Create assignment in Firestore
    const assignmentData = {
      title,
      type,
      chapter,
      topic,
      difficulty,
      createdBy,
      createdAt: new Date().toISOString(),
      dueDate: Timestamp.fromDate(dueDateTime),
      questions,
      status: "active",
    }

    const docRef = await addDoc(collection(db, "assignments"), assignmentData)

    return res.status(201).json({
      id: docRef.id,
      ...assignmentData,
    })
  } catch (error) {
    console.error("Assignment creation error:", error)
    return res.status(500).json({ error: "Failed to create assignment" })
  }
}

