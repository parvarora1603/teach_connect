import { db } from "../../firebase/firebaseConfig"
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { assignmentId, studentId, answers } = req.body

    if (!assignmentId || !studentId || !answers) {
      return res.status(400).json({ error: "Assignment ID, student ID, and answers are required" })
    }

    // Get the assignment to check if it's an MCQ and to calculate the score
    const assignmentDoc = await getDoc(doc(db, "assignments", assignmentId))

    if (!assignmentDoc.exists()) {
      return { success: false, error: "Assignment not found" }
    }

    const assignment = assignmentDoc.data()

    if (assignment.type !== "mcq") {
      return { success: false, error: "This is not an MCQ assignment" }
    }

    // Check if the assignment is still active
    if (assignment.status !== "active") {
      return { success: false, error: "This assignment is no longer active" }
    }

    // Check if the due date has passed
    const now = new Date()
    if (assignment.dueDate.toDate() < now) {
      return { success: false, error: "The due date for this assignment has passed" }
    }

    // Calculate score
    let score = 0
    const questions = assignment.questions

    for (const answer of answers) {
      const question = questions.find((q) => q.id === answer.questionId)
      if (question && question.correctAnswer === answer.answer) {
        score++
      }
    }

    // Create submission
    const submissionData = {
      submittedAt: serverTimestamp(),
      answers,
      score,
      status: "graded", // MCQs are auto-graded
    }

    await setDoc(doc(db, "submissions", "assignments", assignmentId, "students", studentId), submissionData)

    return res.status(200).json({
      score,
      totalQuestions: questions.length,
      percentage: (score / questions.length) * 100,
    })
  } catch (error) {
    console.error("Error submitting MCQ assignment:", error)
    return res.status(500).json({ error: "Failed to submit MCQ answers" })
  }
}

