import { db } from "../../firebase/firebaseConfig"
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { assignmentId, studentId, answers } = req.body

    if (!assignmentId || !studentId || !answers) {
      return res.status(400).json({ error: "Assignment ID, student ID, and answers are required" })
    }

    // Get the assignment to check if it's written
    const assignmentDoc = await getDoc(doc(db, "assignments", assignmentId))

    if (!assignmentDoc.exists()) {
      return { success: false, error: "Assignment not found" }
    }

    const assignment = assignmentDoc.data()

    if (assignment.type !== "written") {
      return { success: false, error: "This is not a written assignment" }
    }

    // Check if the assignment is still active
    if (assignment.status !== "active") {
      return { success: false, error: "This assignment is no longer active" }
    }

    // Check if the due date has passed
    const now = new Date()
    if (assignment.dueDate.toDate() < now) {
      return { success: false, error: "The due date for this assignment has passed" }
    }

    // Create submission
    const submissionData = {
      submittedAt: serverTimestamp(),
      answers,
      status: "submitted", // Written assignments need review
    }

    await setDoc(doc(db, "submissions", assignmentId, studentId), submissionData)

    return res.status(200).json({
      message: "Written assignment submitted successfully",
      submittedAt: submissionData.submittedAt,
    })
  } catch (error) {
    console.error("Error submitting written assignment:", error)
    return res.status(500).json({ error: "Failed to submit written answers" })
  }
}

