import { db } from "../../firebase/firebaseConfig"
import { collection, query, where, orderBy, getDocs } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { studentId } = req.query

    if (!studentId) {
      return res.status(400).json({ error: "Student ID is required" })
    }

    // Get notes for this student, ordered by timestamp (newest first)
    const notesRef = collection(db, "notes", studentId)
    const q = query(notesRef, where("studentId", "==", studentId), orderBy("savedAt", "desc"))

    const notesSnap = await getDocs(q)
    const notes = notesSnap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      savedAt: doc.data().savedAt.toDate(),
    }))

    return res.status(200).json(notes)
  } catch (error) {
    console.error("Get notes error:", error)
    return res.status(500).json({ error: "Failed to get notes" })
  }
}

