import { db } from "../../firebase/firebaseConfig"
import { collection, addDoc, serverTimestamp } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { studentId, question, answer, title = "", tags = [] } = req.body

    if (!studentId || !question || !answer) {
      return res.status(400).json({ error: "Student ID, question, and answer are required" })
    }

    // Save the note to Firestore
    const noteData = {
      studentId,
      question,
      answer,
      title: title || question.substring(0, 50) + "...", // Default title is truncated question
      tags,
      savedAt: serverTimestamp(),
    }

    const docRef = await addDoc(collection(db, "notes"), noteData)

    return res.status(201).json({
      id: docRef.id,
      ...noteData,
    })
  } catch (error) {
    console.error("Save note error:", error)
    return res.status(500).json({ error: "Failed to save note" })
  }
}

