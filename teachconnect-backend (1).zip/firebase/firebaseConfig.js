import { initializeApp } from "firebase/app"
import {
  getFirestore,
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  orderBy,
  Timestamp,
  serverTimestamp,
  writeBatch,
  deleteDoc,
} from "firebase/firestore"
import { getAuth } from "firebase/auth"
import { getStorage } from "firebase/storage"
import { GoogleGenerativeAI } from "@google/generative-ai"

// Your Firebase configuration
const firebaseConfig = {
  // Your Firebase configuration
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)
const db = getFirestore(app)
const auth = getAuth(app)
const storage = getStorage(app)

// Initialize the Google Generative AI with your API key
const genAI = new GoogleGenerativeAI("AIzaSyDrpyFtEstO1DunXgS9y0xb71ubvwfD_YU")

export {
  db,
  auth,
  storage,
  genAI,
  Timestamp,
  serverTimestamp,
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  orderBy,
  writeBatch,
  deleteDoc,
}

