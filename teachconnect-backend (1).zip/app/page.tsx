"use client"

import handler from "../api/auth/register"

export default function SyntheticV0PageForDeployment() {
  return <handler />
}