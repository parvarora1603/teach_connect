import '/flutter_flow/flutter_flow_util.dart';
import 'saved_notes_widget.dart' show SavedNotesWidget;
import 'package:flutter/material.dart';

class SavedNotesModel extends FlutterFlowModel<SavedNotesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
