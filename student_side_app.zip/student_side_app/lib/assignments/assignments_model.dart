import '/flutter_flow/flutter_flow_util.dart';
import 'assignments_widget.dart' show AssignmentsWidget;
import 'package:flutter/material.dart';

class AssignmentsModel extends FlutterFlowModel<AssignmentsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
