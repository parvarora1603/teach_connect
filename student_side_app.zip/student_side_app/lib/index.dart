// Export pages
export '/question_pallette/question_pallette_widget.dart'
    show QuestionPalletteWidget;
export '/first_page/first_page_widget.dart' show FirstPageWidget;
export '/assignments/assignments_widget.dart' show AssignmentsWidget;
export '/chatbot_screen/chatbot_screen_widget.dart' show ChatbotScreenWidget;
export '/saved_notes/saved_notes_widget.dart' show SavedNotesWidget;
